﻿namespace Somativa.Controllers
{
    internal class OpenFileDialog
    {
        internal readonly string FileNome;
        internal object SafeFileNome;
        internal string Filter;

        internal object ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}