﻿namespace Somativa.Controllers
{
    public class Form
    {
    }
}